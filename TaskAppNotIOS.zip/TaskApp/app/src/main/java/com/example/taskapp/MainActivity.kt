package com.example.taskapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.taskapp.ui.navigation.AppNav
import com.example.taskapp.ui.theme.TaskAppTheme
import com.example.taskapp.viewmodel.TasksViewModel

class MainActivity : ComponentActivity() {
    private val tasksViewModel = TasksViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TaskAppTheme {
                AppNav(tasksViewModel)
            }
        }
    }
}
